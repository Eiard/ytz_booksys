create definer = root@localhost trigger returnBorrow
    after update
    on borrow
    for each row
BEGIN
    update reader set rdBorrowQty = rdBorrowQty - 1 where rdId = NEW.rdId;
    update book set bkNum = bkNum + 1 where bkId = NEW.bkId;
end;

