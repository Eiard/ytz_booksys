create definer = root@localhost trigger BookImageUrl
    after insert
    on book
    for each row
BEGIN
    update book set bkImageUrl = '/Book/Image/' + bkId + '.jpg' where bkId = NEW.bkId;
end;

