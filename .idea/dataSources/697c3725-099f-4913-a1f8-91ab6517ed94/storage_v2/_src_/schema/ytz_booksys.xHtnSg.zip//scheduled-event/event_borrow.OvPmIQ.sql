create definer = root@localhost event event_borrow on schedule
    every '1' MINUTE
        starts '2022-03-24 16:42:07'
    on completion preserve
    enable
    comment '判断记录是否逾期'
    do
    update borrow
    set state = 1
    where dateLendAct is null AND state = 0 && NOW() > dateLendPlan;

