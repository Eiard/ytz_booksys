create definer = root@localhost event change_BorrowOverdue on schedule
    every '1' MINUTE
        starts '2022-04-21 21:52:07'
    on completion preserve
    enable
    comment '判断记录是否逾期'
    do
    update borrow
    set overdue = 1
    where isReturn = 0 AND overdue = 0 && NOW() > dateLendPlan;

